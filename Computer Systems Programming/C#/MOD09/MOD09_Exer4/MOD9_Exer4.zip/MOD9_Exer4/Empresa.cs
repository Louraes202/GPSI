﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MOD9_Exer4
{
    internal class Empresa
    {
        private Empregado empregado;
        public Empresa() { 

        }

        public Empresa(Empregado _empregado) {
            this.empregado = _empregado;
        }

    }
}
